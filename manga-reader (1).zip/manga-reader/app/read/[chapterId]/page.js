'use client';

import { useEffect, useState, useCallback } from 'react';
import { getAtHomeServer, buildPageUrls } from '../../../lib/mangadex';

export default function ReadPage({ params }) {
  const { chapterId } = params;
  const [pages, setPages] = useState([]);
  const [index, setIndex] = useState(0);
  const [error, setError] = useState(null);

  useEffect(() => {
    getAtHomeServer(chapterId)
      .then((atHome) => setPages(buildPageUrls(atHome)))
      .catch((e) => setError(e.message));
  }, [chapterId]);

  const next = useCallback(
    () => setIndex((i) => Math.min(i + 1, pages.length - 1)),
    [pages.length]
  );
  const prev = useCallback(() => setIndex((i) => Math.max(i - 1, 0)), []);

  useEffect(() => {
    function onKey(e) {
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft') prev();
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [next, prev]);

  if (error) {
    return <p className="font-mono text-sm text-accent">Error: {error}</p>;
  }
  if (pages.length === 0) {
    return <p className="font-mono text-sm text-muted">Loading...</p>;
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="panel w-full max-w-2xl bg-line min-h-[60vh] flex items-center justify-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={pages[index]}
          alt={`Page ${index + 1}`}
          className="max-w-full max-h-[85vh] object-contain"
        />
      </div>

      <div className="flex items-center gap-4 font-mono text-sm">
        <button
          onClick={prev}
          disabled={index === 0}
          className="border-2 border-paper px-4 py-1 disabled:opacity-30 hover:border-accent hover:text-accent transition-colors"
        >
          ◀ PREV
        </button>
        <span className="text-muted">
          {index + 1} / {pages.length}
        </span>
        <button
          onClick={next}
          disabled={index === pages.length - 1}
          className="border-2 border-paper px-4 py-1 disabled:opacity-30 hover:border-accent hover:text-accent transition-colors"
        >
          NEXT ▶
        </button>
      </div>
      <p className="font-mono text-xs text-muted">
        Use ← / → arrow keys to navigate
      </p>
    </div>
  );
}
