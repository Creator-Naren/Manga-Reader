import { Anton, Inter, JetBrains_Mono } from 'next/font/google';
import Link from 'next/link';
import './globals.css';
import AccessGate from '../components/AccessGate';

const display = Anton({
  subsets: ['latin'],
  weight: '400',
  variable: '--font-display',
});
const body = Inter({ subsets: ['latin'], variable: '--font-body' });
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata = {
  title: 'Panel — Manga Reader',
  description: 'A personal, ad-free manga reader powered by the MangaDex API.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        className={`${display.variable} ${body.variable} ${mono.variable} font-body bg-ink text-paper min-h-screen`}
      >
        <AccessGate>
          <header className="halftone border-b-2 border-paper">
            <div className="bg-ink/90 px-4 py-3 flex items-center justify-between">
              <Link href="/" className="font-display text-2xl tracking-widest">
                PANEL
              </Link>
              <nav className="font-mono text-xs text-muted">
                <span>ad-free · personal reader</span>
              </nav>
            </div>
          </header>
          <main className="max-w-5xl mx-auto px-4 py-6">{children}</main>
          <footer className="max-w-5xl mx-auto px-4 py-8 text-xs text-muted font-mono">
            Manga data and images served via the MangaDex API
            (api.mangadex.org). All credit for content belongs to MangaDex
            and the scanlation groups listed on each chapter.
          </footer>
        </AccessGate>
      </body>
    </html>
  );
}
