const MANGADEX_BASE = 'https://api.mangadex.org';

// Proxies GET requests to api.mangadex.org so the browser never has to
// call MangaDex directly (their API does not send CORS headers to
// third-party origins).
export async function GET(request, { params }) {
  const path = (params.path || []).join('/');
  const search = request.nextUrl.search; // includes leading '?'
  const target = `${MANGADEX_BASE}/${path}${search}`;

  try {
    const upstream = await fetch(target, {
      headers: {
        Accept: 'application/json',
        // MangaDex requires a non-spoofed User-Agent on all requests.
        'User-Agent': 'PanelMangaReader/0.1 (personal use)',
      },
      // MangaDex responses are JSON; no need to forward cookies/auth here
      // since this MVP only uses public, unauthenticated endpoints.
    });

    const body = await upstream.text();
    return new Response(body, {
      status: upstream.status,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return Response.json(
      { error: 'upstream_fetch_failed', detail: String(err) },
      { status: 502 }
    );
  }
}
