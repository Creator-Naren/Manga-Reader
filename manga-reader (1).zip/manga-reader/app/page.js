'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { searchManga, coverUrl, mangaTitle } from '../lib/mangadex';

export default function HomePage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function runSearch(title) {
    setLoading(true);
    setError(null);
    try {
      const data = await searchManga(title);
      setResults(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    runSearch('');
  }, []);

  return (
    <div className="space-y-6">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          runSearch(query);
        }}
        className="flex gap-2"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search manga title..."
          className="flex-1 bg-transparent border-2 border-paper px-3 py-2 font-body focus:outline-none"
        />
        <button
          type="submit"
          className="border-2 border-accent bg-accent text-ink font-display px-5 hover:bg-paper transition-colors"
        >
          GO
        </button>
      </form>

      {!query && (
        <h2 className="font-display text-2xl tracking-wide text-muted">
          POPULAR
        </h2>
      )}

      {loading && <p className="font-mono text-sm text-muted">Loading...</p>}
      {error && (
        <p className="font-mono text-sm text-accent">Error: {error}</p>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {results.map((manga) => {
          const cover = coverUrl(manga);
          return (
            <Link
              key={manga.id}
              href={`/manga/${manga.id}`}
              className="group block"
            >
              <div className="panel aspect-[2/3] overflow-hidden bg-line">
                {cover && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={cover}
                    alt={mangaTitle(manga)}
                    className="w-full h-full object-cover group-hover:opacity-80 transition-opacity"
                    loading="lazy"
                  />
                )}
              </div>
              <p className="mt-2 font-body text-sm leading-tight line-clamp-2">
                {mangaTitle(manga)}
              </p>
            </Link>
          );
        })}
      </div>

      {!loading && results.length === 0 && (
        <p className="font-mono text-sm text-muted">No results.</p>
      )}
    </div>
  );
}
