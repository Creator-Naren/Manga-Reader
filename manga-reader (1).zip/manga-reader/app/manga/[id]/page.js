'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  getManga,
  getChapters,
  coverUrl,
  mangaTitle,
} from '../../../lib/mangadex';

export default function MangaPage({ params }) {
  const { id } = params;
  const [manga, setManga] = useState(null);
  const [chapters, setChapters] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    getManga(id).then(setManga).catch((e) => setError(e.message));
    getChapters(id).then(setChapters).catch((e) => setError(e.message));
  }, [id]);

  if (error) {
    return <p className="font-mono text-sm text-accent">Error: {error}</p>;
  }
  if (!manga) {
    return <p className="font-mono text-sm text-muted">Loading...</p>;
  }

  const description =
    manga.attributes?.description?.en ||
    Object.values(manga.attributes?.description || {})[0] ||
    '';
  const cover = coverUrl(manga, 512);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-6">
        <div className="panel w-40 aspect-[2/3] overflow-hidden bg-line shrink-0">
          {cover && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={cover}
              alt={mangaTitle(manga)}
              className="w-full h-full object-cover"
            />
          )}
        </div>
        <div className="space-y-2">
          <h1 className="font-display text-3xl tracking-wide">
            {mangaTitle(manga)}
          </h1>
          <p className="font-mono text-xs text-muted uppercase">
            {manga.attributes?.status}
          </p>
          {description && (
            <p className="font-body text-sm text-paper/80 max-w-2xl whitespace-pre-line">
              {description}
            </p>
          )}
        </div>
      </div>

      <div>
        <h2 className="font-display text-xl tracking-wide mb-2 border-b-2 border-paper pb-1">
          CHAPTERS
        </h2>
        {chapters.length === 0 && (
          <p className="font-mono text-sm text-muted">
            No English chapters found.
          </p>
        )}
        <ul className="divide-y divide-line">
          {chapters.map((ch) => {
            const group = ch.relationships?.find(
              (r) => r.type === 'scanlation_group'
            );
            return (
              <li key={ch.id}>
                <Link
                  href={`/read/${ch.id}`}
                  className="flex items-center justify-between py-2 hover:text-accent transition-colors"
                >
                  <span className="font-body text-sm">
                    Ch. {ch.attributes?.chapter ?? '?'}
                    {ch.attributes?.title ? ` — ${ch.attributes.title}` : ''}
                  </span>
                  <span className="font-mono text-xs text-muted">
                    {group?.attributes?.name || ''}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
